
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

/**
 *
 * @author Julian
 */
public class SnowFlakeFrame extends javax.swing.JFrame {

    /**
     * Creates new form SnowFlakeFrame
     */
    public SnowFlakeFrame() {
        initComponents();
        this.setSize(1024, 748);

        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                jLabel1.setText("" + getWidth() + ", " + getHeight());
            }

        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        snowFlakePanel1 = new SnowFlakePanel();
        editorControl = new javax.swing.JPanel();
        newButton = new javax.swing.JButton();
        importPointsButton = new javax.swing.JButton();
        savePointsButton = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        generateButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        editor = new SnowFlakePanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(1024, 748));

        editorControl.setLayout(new java.awt.GridLayout(7, 1));

        newButton.setText("New");
        editorControl.add(newButton);

        importPointsButton.setText("Import points");
        editorControl.add(importPointsButton);

        savePointsButton.setText("Save points");
        savePointsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savePointsButtonActionPerformed(evt);
            }
        });
        editorControl.add(savePointsButton);

        jButton6.setText("Save Snowflake");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        editorControl.add(jButton6);

        jButton7.setText("Reset");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        editorControl.add(jButton7);

        generateButton.setText("Generate");
        generateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generateButtonActionPerformed(evt);
            }
        });
        editorControl.add(generateButton);

        jLabel1.setText("jLabel1");
        editorControl.add(jLabel1);

        getContentPane().add(editorControl, java.awt.BorderLayout.EAST);
        getContentPane().add(editor, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void savePointsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savePointsButtonActionPerformed
        try {
            editor.savePoints();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SnowFlakeFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(SnowFlakeFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_savePointsButtonActionPerformed

    private void generateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generateButtonActionPerformed
        if (editor.getFinalPolygon() != null) {
            editor.generate();
            this.setResizable(false);
        }
    }//GEN-LAST:event_generateButtonActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        try {
            editor.saveImage();
        } catch (IOException ex) {
            Logger.getLogger(SnowFlakeFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        editor.removeAll();
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SnowFlakeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SnowFlakeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SnowFlakeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SnowFlakeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SnowFlakeFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private SnowFlakePanel editor;
    private javax.swing.JPanel editorControl;
    private javax.swing.JButton generateButton;
    private javax.swing.JButton importPointsButton;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton newButton;
    private javax.swing.JButton savePointsButton;
    private SnowFlakePanel snowFlakePanel1;
    // End of variables declaration//GEN-END:variables
}
