
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.PathIterator;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author Julian Sprugasci
 * @version last_release
 */
public class SnowFlakePanel extends JPanel implements MouseListener, MouseMotionListener, ComponentListener {

    private final int POINT_SIZE = 10;

    private int xMouse;

    private int yMouse;

    private boolean isPressed = false;

    private List<MyPolygon> myPolygons = new ArrayList<>();

    //private MyPolygon myPolygon = new MyPolygon();
    private Point lastPoint;

    private Triangle triangle;

    private Area triangleArea;

    private boolean clearArea = false;

    private boolean drawFinalPolygon = false;

    Polygon finalPolygon = new Polygon();

    private BufferedImage imgFinalPolygon;

    private int lastWidth = 1024;

    private int lastHeight = 748;

    private boolean isReset = false;

    private Color backgroundColor = new Color(189, 195, 199);

    private Color areaColor = new Color(0, 255, 0, 80);

    private Color pointsColor = Color.red;

    private int xCoord = 0;

    private int yCoord = 0;

    private boolean isNull = false;

    public SnowFlakePanel() {
        init();
        this.setSize(1024, 748);
        this.setDoubleBuffered(true);
        this.setLayout(null);
        //this.setBackground(backgroundColor);
        addMouseListener(this);
        addMouseMotionListener(this);
        addComponentListener(this);
        System.err.println(this.getWidth());
        System.err.println(this.getHeight());

    }

    public void init() {
        triangle = new Triangle();
        triangleArea = new Area(triangle.getPolygon());
        myPolygons.add(new MyPolygon());
        xMouse = 0;
        yMouse = 0;
        lastPoint = new Point();
    }

    public void calculatePolygon(MouseEvent e) {
        MyPolygon lastPolygon = myPolygons.get(myPolygons.size() - 1);
        if (!lastPolygon.getIsClosed()) {
            lastPolygon.addPoint(new Point(e.getX(), e.getY()));
        } else {
            myPolygons.add(new MyPolygon());
            lastPolygon = myPolygons.get(myPolygons.size() - 1);
            lastPolygon.addPoint(new Point(e.getX(), e.getY()));
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Toolkit.getDefaultToolkit().sync();
        g.setColor(backgroundColor);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        Graphics2D g2 = (Graphics2D) g;
        g.setColor(Color.red);

        if (this.getWidth() != this.lastWidth || this.getHeight() != this.lastHeight) {

            this.lastWidth = this.getWidth();
            this.lastHeight = this.getHeight();
            triangle.createTriangle();
        }

        triangle.paintComponent(g);

        for (int i = 0; i < myPolygons.size(); i++) {

            myPolygons.get(i).paint(g, areaColor, pointsColor);
        }

        if (this.clearArea) {

            g.setColor(Color.cyan);
            g.fillRect(0, 0, this.getWidth(), this.getHeight());
        }

        /*if (this.isReset) {
            g.clearRect(0, 0, this.getWidth(), this.getHeight());
            g.setColor(Color.cyan);
            g.fillRect(0, 0, this.getWidth(), this.getHeight());
        }*/
        if (this.drawFinalPolygon) {

            g.setColor(Color.white);
            //g.fillPolygon(this.finalPolygon);
            //testPoint(g);
            Shape[] shapes = new Shape[6];//finalPolygon
            int count = 0;
            for (int i = 0; i < shapes.length; i++) {
                shapes[i] = rotatePointMatrix(count, this.finalPolygon);
                g2.fill(shapes[i]);
                count += 60;
            }
            Polygon reserved = reversePolygon();
            Shape[] reversedRotate = new Shape[6];
            count = 0;
            for (int i = 0; i < 6; i++) {
                reversedRotate[i] = rotatePointMatrix(count, reserved);
                g2.fill(reversedRotate[i]);
                count += 60;
            }

        }
    }

    public boolean containsPoints(int x, int y) {
        return lastPoint.distance(new Point(x, y)) <= POINT_SIZE / 2;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        this.xMouse = e.getX();
        this.yMouse = e.getY();
        System.err.println("X: " + e.getX() + ", Y: " + e.getY());
        System.err.println("Width: " + this.getWidth() / 2 + ", Height: " + this.getHeight() / 2);
        this.lastPoint = new Point(xMouse, yMouse);
        try {
            if (e.getButton() == MouseEvent.BUTTON1) {
                calculatePolygon(e);
                repaint();
            }
            if (e.getButton() == MouseEvent.BUTTON3) {
                myPolygons.get(myPolygons.size() - 1).removePointAt(lastPoint);
                repaint();
            }
        } catch (ConcurrentModificationException cme) {
            System.err.println("Cancelled!");
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        lastPoint = new Point(e.getPoint());
        for (int i = 0; i < myPolygons.size(); i++) {
            myPolygons.get(i).movePoint(lastPoint, e.getPoint());
            myPolygons.get(i).recalculatePolygon();
            repaint();
        }

    }

    @Override
    public void mouseMoved(MouseEvent e) {
        xCoord = e.getX();
        yCoord = e.getY();
    }

    public void savePoints() throws FileNotFoundException, UnsupportedEncodingException {
        try {
            String name = JOptionPane.showInputDialog(null, "Insert the file name with .txt");
            char[] controlName = name.toCharArray();
            if (!controlFileName(controlName, name)) {
                JOptionPane.showMessageDialog(null, "Please, insert a .txt file!");
            }else if(myPolygons.get(0).getPoints().size() < 1){
                JOptionPane.showMessageDialog(null, "Please, insert a least one point!");
            }else{
                String finalPath = "Files/" + name;
                PrintWriter writer = new PrintWriter(finalPath, "UTF-8");
                for (MyPolygon polygon : myPolygons) {
                    System.out.println("NEP NEP");
                    for (Point point : polygon.getPoints()) {
                        writer.println(point.getX());
                        writer.println(point.getY());
                        System.out.println("NIGLU");
                    }
                    writer.println("endpolygon");
                }
                writer.close();
            }
        } catch (NullPointerException npe) {
            JOptionPane.showMessageDialog(null, "Please, insert a valid name!");
        }

    }

    public void importPoints() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Import Points");
        int status = fc.showOpenDialog(null);
        if (status == JFileChooser.APPROVE_OPTION) {
            try {
                File file = fc.getSelectedFile();
                Path path = Paths.get(file.getPath());
                List<String> points = Files.readAllLines(path);
                int[] xPolygons;
                int[] yPolygons;
                List<Integer> index = new ArrayList<>();
                List<Integer> x = new ArrayList<>();
                List<Integer> y = new ArrayList<>();
                int count = 0;
                for (int i = 0; i < points.size(); i++) {
                    if (points.get(i).equals("endpolygon")) {
                        count++;
                        index.add(i / 2);
                        //System.err.println(index.get(i));
                    }
                }
                x = points.stream().map(s -> Integer.parseInt(s)).collect(Collectors.toList());
                /*for (int i = 0; i < x.size(); i++) {
                    //System.err.println(x.get(i));
                }*/
            } catch (IOException ex) {
                //Logger.getLogger(SnowFlakePanel.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            System.err.println("Error!");
        }

    }

    public void saveImage(String name, int width, int height, int type) throws FileNotFoundException, IOException {
        //int widthResult = width - 124;
        //int heightResult = height - 28;
        int widthResult = width;
        int heightResult = height;
        switch (type) {
            case 1:
                if (widthResult == 500 && heightResult == 500 || widthResult == 1000 && heightResult == 1000 || widthResult == this.getWidth() && heightResult == this.getHeight()) {
                    imgFinalPolygon = new BufferedImage(widthResult, heightResult, BufferedImage.TYPE_3BYTE_BGR);
                    //this.setSize(this.getWidth(), this.getHeight());
                    this.paintComponent(imgFinalPolygon.getGraphics());
                    File outputfile = new File("Img/" + name + ".jpg");
                    ImageIO.write(imgFinalPolygon, "jpg", outputfile);
                    System.err.println("SHISH");
                }
                break;
            case 2:
                if (widthResult == 500 && heightResult == 500 || widthResult == 1000 && heightResult == 1000 || widthResult == this.getWidth() && heightResult == this.getHeight()) {
                    imgFinalPolygon = new BufferedImage(widthResult, heightResult, BufferedImage.TYPE_3BYTE_BGR);
                    //this.setSize(this.getWidth(), this.getHeight());
                    this.paintComponent(imgFinalPolygon.getGraphics());
                    File outputfile = new File("Img/" + name + ".png");
                    ImageIO.write(imgFinalPolygon, "png", outputfile);
                    System.err.println("SHISH");
                }
                break;
            case 3:
                if (widthResult == 500 && heightResult == 500 || widthResult == 1000 && heightResult == 1000 || widthResult == this.getWidth() && heightResult == this.getHeight()) {
                    imgFinalPolygon = new BufferedImage(widthResult, heightResult, BufferedImage.TYPE_3BYTE_BGR);
                    //this.setSize(this.getWidth(), this.getHeight());
                    this.paintComponent(imgFinalPolygon.getGraphics());
                    File outputfile = new File("Img/" + name + ".png");
                    ImageIO.write(imgFinalPolygon, "png", outputfile);
                    System.err.println("SHISH");
                }
                break;
            default:
                break;
        }
    }

    public void resetAll() {
        myPolygons.removeAll(myPolygons);
        this.isReset = true;

    }

    public boolean controlFileName(char[] chars, String name) {
        if(name != null && !name.equals("") && !name.equals(" ")){
            return chars[chars.length - 1] == 't' && chars[chars.length - 2] == 'x'
                && chars[chars.length - 3] == 't'
                && chars[chars.length - 4] == '.';
        }
        return false;
    }

    public void subtractArea() {
        if (this.finalPolygon != null) {
            for (int i = 0; i < this.myPolygons.size(); i++) {
                triangleArea.subtract(this.myPolygons.get(i).getArea());
            }
        }
    }

    public void convertAreaToPolygon() {
        PathIterator iterator = triangleArea.getPathIterator(null);
        float[] floats = new float[6];
        this.finalPolygon = new Polygon();
        ArrayList<Point> startPoints = new ArrayList<>();
        while (!iterator.isDone()) {
            int type = iterator.currentSegment(floats);
            int x = (int) floats[0];
            int y = (int) floats[1];
            if (type == 0) {
                startPoints.add(new Point(x, y));
            }
            this.finalPolygon.addPoint(x, y);
            if (type == 4) {
                x = startPoints.get(startPoints.size() - 1).x;
                y = startPoints.get(startPoints.size() - 1).y;
                this.finalPolygon.addPoint(x, y);
            }
            iterator.next();
        }
        for (int i = 0; i < startPoints.size(); i++) {
            this.finalPolygon.addPoint(startPoints.get(i).x, startPoints.get(i).y);

        }

    }

    public void generate() {
        try {
            this.subtractArea();
            this.convertAreaToPolygon();
            this.clearArea = true;
            this.drawFinalPolygon = true;
            scaleFinalPolygon();
            repaint();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Please, insert at least one polygon!");
            this.isNull = true;
        }

    }

    public Polygon getFinalPolygon() {
        return this.finalPolygon;
    }

    @Override
    public void componentResized(ComponentEvent arg0) {
        //triangle = new Triangle();
        triangleArea = new Area(triangle.getPolygon());
        triangle.resize(this.getHeight(), this.getWidth());
        //System.err.println(triangle.getWindowWidth());
        //repaint();
    }

    @Override
    public void componentMoved(ComponentEvent arg0) {

    }

    @Override
    public void componentShown(ComponentEvent arg0) {

    }

    @Override
    public void componentHidden(ComponentEvent arg0) {

    }

    public Shape rotatePointMatrix(double angle, Polygon polygon) {

        AffineTransform tx = new AffineTransform();
        tx.rotate(Math.toRadians(angle), this.getWidth() / 2, this.getHeight() / 2);
        //tx.translate(angle, angle);
        //Shape s = tx.createTransformedShape(this.finalPolygon);
        Shape s = tx.createTransformedShape(polygon);
        return s;

    }

    public void scaleFinalPolygon() {
        int maxPointY = 0;
        for (int i = 0; i < this.finalPolygon.ypoints.length; i++) {
            if (this.finalPolygon.ypoints[i] > maxPointY) {
                maxPointY = this.finalPolygon.ypoints[i];
            }
        }
        int difference = Math.abs(maxPointY - (this.getHeight() / 2));
        //System.err.println("Difference: " + difference);
        for (int i = 0; i < this.finalPolygon.ypoints.length; i++) {
            this.finalPolygon.ypoints[i] -= difference;
        }

        int maxPointX = 0;
        for (int i = 0; i < this.finalPolygon.xpoints.length; i++) {
            if (this.finalPolygon.xpoints[i] > maxPointX) {
                maxPointX = this.finalPolygon.xpoints[i];
            }
        }
        int differenceX = Math.abs(maxPointX - (this.getWidth() / 2));
        //System.err.println("Difference: " + difference);
        for (int i = 0; i < this.finalPolygon.xpoints.length; i++) {
            this.finalPolygon.xpoints[i] -= differenceX;
        }

    }

    public Polygon reversePolygon() {
        int difference = 0;
        int centerX = this.getWidth() / 2;
        int[] xPos = new int[this.finalPolygon.xpoints.length];
        for (int i = 0; i < this.finalPolygon.xpoints.length; i++) {
            difference = Math.abs(this.finalPolygon.xpoints[i] - centerX);
            xPos[i] = centerX + difference;
        }
        Polygon reversedPolygon = new Polygon(xPos, this.finalPolygon.ypoints, this.finalPolygon.npoints);
        return reversedPolygon;

    }

    public Triangle getTriangle() {
        return this.triangle;
    }

    public void setPointsColor(Color color) {
        this.pointsColor = color;
    }

    public void setAreaColor(Color color) {
        this.areaColor = color;
    }

    public void setBackgroundColor(Color color) {
        this.backgroundColor = color;
    }

    /**
     * Ritorna se c'è una NullPointerException
     *
     * @return isNull
     */
    public boolean getIsNull() {
        return this.isNull;
    }

}
