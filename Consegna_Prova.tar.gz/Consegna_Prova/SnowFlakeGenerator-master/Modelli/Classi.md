### Descrizione Classi e metodi

#### MyPolygon.java


##### Metodo addPoint
![c](Img/addPoint.png)

Questo metodo controlla la distanza tra il primo punto del poligono di taglio inserito con il click sinistro del mouse e l'ultimo inserito. Se la distanza fra i due è minore del valore prestabilito, in questo caso 5, setta il booleano **isClosed**, chiude il poligono e crea l'area del poligono.

##### Metodo recalculatePolygon
![c](Img/recalculatePolygon.png)

Questo metodo permette di resettare il poligono attuale e, ciclando con un for each riassegna i valori al poligono aggiornandolo. Successivamente ricrea l'area del poligono. Esso viene utilizzato nel mouse Dragged per ricalcolare i poligoni ogni volta che vengono trascinati.

##### Metodo removePointAt
![c](Img/removePointAt.png)

Questo metodo permette di controllare se il click del mouse coincide con uno dei punti disegnati del poligono. Se, premendo col tasto destro del mouse il due punti coincidono, allora esso viene tolto dal poligono e richiama il **recalculatePolygon()**. Questo metodo viene utilizzato nel **mouseClick** per controllare se l'utente vuole cancellare un punto.

##### Metodo movePoint
![c](Img/movePoint.png)

Questo metodo controlla se la distanza tra il punto "selezionato" e il click sinistro del mouse coincidono con i valori prestabiliti. Se tutto va a buon fine il punto viene aggiornato con il **newPosition**.

##### Metodo distanceOfPoints
![c](Img/distanceOfPoints.png)

Questo metodo ritorna se la distanza fra due punti coincide con il valore di **RADIUS * 2** altrimenti ritorna false.

#### SnowFlakeFrame2.java

##### Metodo startButton1ActionPerformed
![c](Img/startButton1ActionPerformed.png)

Questo metodo permette di creare un nuovo EditorPanel all'interno del mio TabbedPane.

##### Metodo helpButtonActionPerformed
![c](Img/helpButton.png)

Questo metodo permette di creare una pagina di Help all'interno del nostro TappedPane.

##### Metodo createTriangle
![c](Img/createTriangle.png)

Questo metodo permette di creare un triangolo sempre centrato al centro dello schermo attraverso dei calcoli matematici. Esso viene richiamato ogni volta che voglio ridimensionare il triangolo con un resize.

##### Metodo jButton6ActionPerformed
![c](Img/saveImagAP.png)

Questo metodo controlla se l'utente ha scelto il tipo di immagine da salvare. Se non lo sceglie esce un messaggio di errore, altrimenti salva l'immagine e stampa il messaggio che tutto è andato a buon fine.

##### Metodo jpgButtonActionPerformed
![c](Img/jpgButtonAP.png)

Questo metodo controlla se l'utente ha scelto come tipo di immagine jpg. Se ha scelto esso di conseguenza resetta gli altri colori dei bottoni e si setta attivo.

##### Metodo pngButtonActionPerformed
![c](Img/pngButtonAP.png)

Questo metodo controlla se l'utente ha scelto come tipo di immagine png. Se ha scelto esso di conseguenza resetta gli altri colori dei bottoni e si setta attivo.

##### Metodo svgButtonActionPerformed
![c](Img/svgButtonAP.png)

Questo metodo controlla se l'utente ha scelto come tipo di immagine svg. Se ha scelto esso di conseguenza resetta gli altri colori dei bottoni e si setta attivo.

##### Metodo polygonsColorButtonActionPerformed
![c](Img/polygonsColorButtonAP.png)

Questo metodo si occupa di cambiare il colore dei poligoni di taglio e cambiare il colore di sfondo del bottone.

##### Metodo darkModeCheckBoxActionPerformed
![c](Img/darkModeCheckBoxAP.png)

Questo metodo è un po' un casino ma si occupa solamente di controllare se il checkBox della Dark Mode è attivo oppure è disattivato.

##### Metodo backgroundColorButtonActionPerformed
![c](Img/backgroundColorButtonAP.png)

Questo metodo si occupa di cambiare il colore dello sfondo dell'applicazione e cambiare il colore di sfondo del bottone.

##### Metodo pointsColorButtonActionPerformed
![c](Img/pointsColorButtonAP.png)

Questo metodo si occupa di cambiare il colore dei punti e cambiare il colore di sfondo del bottone.

##### Metodo generateButtonActionPerformed
![c](Img/generateButtonAP.png)

Questo metodo ogni volta che viene richiamato aumenta una variabile chiamata **countGenerate**. Questa variabile serve per un semplice motivo, se è uguale a 1 crea il panel della Preview e lo aggiunge all'editor mentre se è maggiore di 1 si limita semplicemente di fare repaint della finestra e del PreviewPanel. Al suo interno c'è una condizione che si avvera solamente quando l'utente preme **Yes** per generare il fiocco di neve.

##### Metodo resetButtonActionPerformed
![c](Img/resetButtonAP.png)

Questo metodo si occupa di resettare tutti i punti e poligoni presenti in quel momento sulla finestra dell'editor.

##### Metodo savePointsButtonActionPerformed
![c](Img/savePointsButtonAP.png)

Questo metodo invoca il metodo **savePoints** di SnowFlakePanel e permette semplicemente di salvare i punti in un file .txt.

##### Metodo importPointsButtonActionPerformed
![c](Img/importPointsButtonAP.png)

Questo metodo invoca il metodo **importPoints** di SnowFlakePanel e permette semplicemente di importare i file .txt.

##### Metodo triangleColorButtonActionPerformed
![c](Img/triangleColorButtonAP.png)

Questo metodo si occupa di cambiare il colore del triangolo di base e cambiare il colore di sfondo del bottone.

##### Metodo calculatePolygon
![c](Img/calculatePolygon.png)

Questo metodo crea innanzitutto un **lastPolygon** che corrisponde all'ultimo poligono di **myPolygons**. Con esso controllo, se non è chiuso inserisco i punti al suo interno mentre se esso è chiuso allora lo aggiungo alla lista.

##### Metodo calculateShape
![c](Img/calculateShape.png)

Questo metodo come prima cosa crea una variabile **count**. Essa verrà incrementata e utilizzata per girare gli shape con un determinato angolo di rotazione. Poi fa passare prima tutti gli shape e li ruota ad ogni ciclo di 60 gradi grazie a count ma anche al metodo **rotatePointMatrix**. Una volta fatto con gli shape normali lo stesso processo viene effettuato anche per gli Shape specchiati, perchè come sappiamo un esagono è formato da sei triangoli normali e sei specchiati come in questo caso.

##### Metodo containsPoints
![c](Img/containsPoints.png)

Questo metodo verifica se due punti sono all'interno di una determinata distanza. In questo caso deve essere minore di **POINTS_SIZE / 2**.

##### Metodo mouseClicked
![c](Img/mouseClicked.png)

Questo metodo gestisce gli eventi click del mouse. Come prima cosa vengono inizializzate due variabili che permettono di tenere traccia dell'ultimo punto in cui si ha cliccato col mouse. Poi controlla se il viene cliccato il tasto **sinistro** del mouse richiamo il metodo **calculatePolygon**, altrimenti se viene premuto quello destro è possibile cancellare il punto selezionato.

##### Metodo mouseDragged
![c](Img/mouseDragged.png)

Questo metodo permette di trascinare i punti all'interno della finestra dell'editor. Infatti salvando le vecchie coordinate del mouse posso spostarle e modificarle in quelle nuove attraverso **movePoint** e a **recalculatePolygon**.

##### Metodo mouseMoved
![c](Img/mouseMoved.png)

Questo metodo si occupa principalmente ad aggiornare le coordinate di **xCoord e yCoord** per ogni movimento del mouse.

##### Metodo savePoints
![c](Img/savePoints.png)

Questo metodo ha lo scopo di salvare i punti dei vari poligoni presenti sull'editor. Come prima cosa chiede all'utente di inserire il nome del file nel quale si desidera salvare i punti.

**Nota:** Il nome del file deve contenere alla fine l'estensione .txt per funzionare correttamente sennò scatenerà un errore.

Una volta preso il nome controlla con un metodo se l'estensione del file e giusta, se tutto ciò va a buon fine procederà a salvare i vari punti nel file.

I punti verranno salvati del seguente modo seguendo questo stile:

![c](Img/fileExample.png)

##### Metodo importPoints
![c](Img/importPoints.png)

Questo metodo permette di importare i punti da un file .txt all'interno del programma. Il processo è molto semplice. Tutto parte dalla scelta del file tramite il file Chooser. Una volta scelto il file viene passato il file finchè non trova la scritta **endPolygon** e allora capisce che li finisce un poligono. Una volta fatti passare tutti i poligoni ed aver inserito man mano i punti in sue liste, essi li converto in Integer e li aggiungo alla lista di poligoni.

##### Metodo saveImage
![c](Img/saveImage.png)

Questo metodo permette di salvare il fiocco di neve finale nei formati richesti **(png,jpg,svg)**. Si può salvare l'immagine con le grandezze 500, 1000 oppure con quella corrente che viene mostrata con un jLabel sull'editor.

##### Metodo controlFileName
![c](Img/controlFileName.png)

Questo metodo controlla se l'estensione del file corrisponde a quella del .txt.

##### Metodo subtractArea
![c](Img/subtractArea.png)

Questo metodo permette di sottrarre tutte le aree dei poligoni che sono in sovrapposizione con il triangolo.

##### Metodo convertAreaToPolygon
![c](Img/convertAreaToPolygon.png)

Questo metodo permette convertire l'area finale del triangolo di nuovo ad un poligono. Per farlo o utilizzato il Path Iterator che funziona nel seguente modo. Esso parte da type 0 percorre tutti i punti di un poligono a type 1 e all'ultimo punto arriva a 4. in questo modo si possono passare tutti i punti dell'area e recuperare quelli originali per rimetterli in un poligono.

##### Metodo generate
![c](Img/generate.png)

Questo metodo permette di generare il fiocco di neve finale, richiamando i vari metodi che gli serviranno durante il progesso di creazione.

##### Metodo componentResized
![c](Img/componentResized.png)

Questo metodo viene richiamato ogni qual volta viene effettuato un ridimensionamento della finestra e permette di aggiornale la grandezza e la posizione del triangolo per far si che rimanga sempre centrato.

##### Metodo rotatePointMatrix
![c](Img/rotatePointMatrix.png)

Questo metodo permette di ruotare i punti del poligono utilizzando la classe AffineTrasform. Questa classe non è altro che la rappresentazione delle trasformazioni affini matematiche e fornisce dei metodi molto interessanti. Utilizzando il metodo **scale** è possibile scalare la grandezza del poligono e renderlo più piccolo mentre il metodo **rotate** permett di scegliere l'angolo di rotazione, e i punti da fissare durante la rotazione (in questo caso il punto più in basso del triangolo) e visto che deve essere spostato al centro c'è bisogno di creare un metodo che faccia il sequente lavoro. Una volta fatto tutto ciò si può creare **createTrasformedShape** e ritornare lo shape trasformato.

##### Metodo reversePolygon
![c](Img/reversePolygon.png)

Questo metodo permette di specchiare uno shape per permettere di disegnare il fiocco di neve nel modo corretto. Il come è molto semplice. si calcola la differenza tra i punti sull'asse x fino al centro della figura. Dopodichè si usa quella differenza per spostare i punti dall'altra parte e specchiarli correttamente.
