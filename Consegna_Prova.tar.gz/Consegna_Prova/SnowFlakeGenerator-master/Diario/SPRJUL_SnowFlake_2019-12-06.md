# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 06.12.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Modifica del sistema grafico e risoluzione problemi responsive.||

##  Problemi riscontrati e soluzioni adottate
1. Problemi con la risoluzione del responsive.

##  Punto della situazione rispetto alla pianificazione
Leggermente indietro con la documentazione e il sito

## Programma di massima per la prossima giornata di lavoro
1. Cercare di risolvere i problemi del responsive.
2. Portarsi verso una conclusione.


