# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 13.09.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Risoluzione problemi precedenti|
|13:15 - 16:60 |Documentazione      ||

##  Problemi riscontrati e soluzioni adottate
Nessun problema riscontrato durante questa giornata.

##  Punto della situazione rispetto alla pianificazione
A passo con il programma

## Programma di massima per la prossima giornata di lavoro
1. Continuare con la programmazione dell'applicazione

