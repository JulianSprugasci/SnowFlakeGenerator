# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 07.09.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|19:00 - 20:00 |Creazione Documentazione e modifica dell'introduzione|
|20:00 - 20:05 |Aggiunta consegna progetto e modifica      |
|20:05 - 20:30 |Modifica del README                           |

##  Problemi riscontrati e soluzioni adottate
Nessun problema riscontrato durante questa giornata.
Risoluzione di tutti i problemi della scorsa volta.

##  Punto della situazione rispetto alla pianificazione
Manca analisi del progetto e lista dei requisiti

## Programma di massima per la prossima giornata di lavoro

1. Fare analisi e requisiti del progetto
1. Pensare alla pianificazione del progetto
