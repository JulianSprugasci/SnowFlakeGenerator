# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 13.12.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|8:20 - 11:45|Modifica del sistema grafico e risoluzione problemi generazione.|
|13:15 - 16:30|Modifica del sistema grafico e risoluzione problemi generazione.||

##  Problemi riscontrati e soluzioni adottate
1. Problemi con la risoluzione della generazione.

##  Punto della situazione rispetto alla pianificazione
Indietro con la documentazione. Previsto recupero per il weekend

## Programma di massima per la prossima giornata di lavoro
1. Finire il progetto.
2. Finire documentazione.


