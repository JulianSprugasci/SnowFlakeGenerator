# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 25.10.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Implementazione classe principale|
|13:15 - 16:60 |Implementazione classe principale||

##  Problemi riscontrati e soluzioni adottate
Nessun problema riscontrato durante questa giornata.

##  Punto della situazione rispetto alla pianificazione
A passo con il programma

## Programma di massima per la prossima giornata di lavoro
1. Continuare con l'implementazione della classe principale
2. Iniziare a gestire i punti e le linee
