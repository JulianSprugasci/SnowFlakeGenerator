# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 18.10.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Testing design e responsive|
|13:15 - 16:60 |Testing     ||

##  Problemi riscontrati e soluzioni adottate
Rallentamento dovuto a un problema con il ridimensionamento degli oggetti

##  Punto della situazione rispetto alla pianificazione
A passo con il programma

## Programma di massima per la prossima giornata di lavoro
1. Iniziare con la programmazione del programma
2. Sperimentare il funzionamento su carta
