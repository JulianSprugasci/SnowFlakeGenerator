# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 11.10.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Implementazione interfaccia|
|13:15 - 16:60 |Design Interfaccia      ||

##  Problemi riscontrati e soluzioni adottate
Nessun problema riscontrato durante questa giornata.

##  Punto della situazione rispetto alla pianificazione
A passo con il programma

## Programma di massima per la prossima giornata di lavoro
1. Continuare con il design dei menu e delle interfacce

