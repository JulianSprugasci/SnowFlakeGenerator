# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 01.11.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Implementazione dei punti e linee|
|13:15 - 16:60 |Implementazione del poligono di taglio     ||

##  Problemi riscontrati e soluzioni adottate
1. Problema con il taglio del triangolo
2. I punti non si spostano correttamente

##  Punto della situazione rispetto alla pianificazione
Leggermente in ritardo ma recuperato nel weekend.

## Programma di massima per la prossima giornata di lavoro
1. Sistemare i bug e andare avanti con l'implementazione.
