# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 13.09.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Risoluzione dubbi e requisiti|
|13:15 - 16:60 |Documentazione      ||

##  Problemi riscontrati e soluzioni adottate
Nessun problema riscontrato durante questa giornata.

##  Punto della situazione rispetto alla pianificazione
Mancano alcuni requisiti.

## Programma di massima per la prossima giornata di lavoro
1. Iniziare il Gantt
1. Continuare con la programmazione dell'applicazione

