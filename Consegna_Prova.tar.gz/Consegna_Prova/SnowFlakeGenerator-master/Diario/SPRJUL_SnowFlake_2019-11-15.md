# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 15.11.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Ri-implementazione delle classi|
|13:15 - 16:60 |Ricreazione di una struttura più solida     ||

##  Problemi riscontrati e soluzioni adottate
1. ERRORE FATALE nella struttura del codice. Dovuto ricominciare da capo
2. Problemi generali
##  Punto della situazione rispetto alla pianificazione
In ritardo con l'implementazione. Recupero previsto a casa per tornare a passo

## Programma di massima per la prossima giornata di lavoro
1. Andare avanti e recuperare le cose fatte in precedenza
