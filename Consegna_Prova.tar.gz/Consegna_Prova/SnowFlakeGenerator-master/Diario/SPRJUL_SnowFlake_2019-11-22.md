# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 22.11.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Implementazione generazione fiocco di neve|
|13:15 - 16:60 |Generazione e ruotazione del poligono.     ||

##  Problemi riscontrati e soluzioni adottate
1. Problemi con la classe PathIterator e AffineTrasform, ora però risolti.

##  Punto della situazione rispetto alla pianificazione
A passo con il programma

## Programma di massima per la prossima giornata di lavoro
1. Cercare di andare verso una conclusione del progetto
2. Rendere il programma privo di errori.
3. Iniziare a rendere il programma autonomo.
