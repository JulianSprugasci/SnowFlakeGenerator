# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 06.09.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|14:15 - 14:45   |Installazione Git e configurazione .gitconfig          |
|15:00 - 16:30 | Installazione di GitHub Desktop e tentata clonazione della repository     |
|...           |...                           |

##  Problemi riscontrati e soluzioni adottate
Problema ad accedere a GitHub Desktop per problema col Proxy

##  Punto della situazione rispetto alla pianificazione
Manca analisi del progetto e lista dei requisiti

## Programma di massima per la prossima giornata di lavoro
1. Collegarmi a GitDesktop
1. Clonare la Repository
1. Fare analisi e requisiti del progetto
1. Pensare alla pianificazione del progetto
