# Generatore di fiocchi di neve | Diario di lavoro
##### Sprugasci Julian
### Sam Trevano, 08.11.2019

## Lavori svolti


|Orario        |Lavoro svolto                 |
|--------------|------------------------------|
|10:05 - 11:45|Implementazione dei vari poligoni|
|13:15 - 16:60 |Implementazione con aggiunta bottoni||

##  Problemi riscontrati e soluzioni adottate
1. Problemi con input dei bottoni

##  Punto della situazione rispetto alla pianificazione
A passo con il programma

## Programma di massima per la prossima giornata di lavoro
1. Sistemare i bug e continuare.
